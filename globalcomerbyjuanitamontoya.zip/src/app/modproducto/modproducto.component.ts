import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modproducto',
  templateUrl: './modproducto.component.html',
  styleUrls: ['./modproducto.component.css']
})
export class ModproductoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}