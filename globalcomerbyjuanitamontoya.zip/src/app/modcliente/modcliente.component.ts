import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modcliente',
  templateUrl: './modcliente.component.html',
  styleUrls: ['./modcliente.component.css']
})
export class ModclienteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}