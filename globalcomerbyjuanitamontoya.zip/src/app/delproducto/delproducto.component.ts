import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delproducto',
  templateUrl: './delproducto.component.html',
  styleUrls: ['./delproducto.component.css']
})
export class DelproductoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}